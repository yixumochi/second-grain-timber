"""Read-only Case 2 sample validation; writes only beside this script.

Run with Python + numpy. Existing R03 solver results are read, hash-bound and
cross-checked. No native solve, stiffness assumption, geometry or stock edit.
All coordinates and clearances are working-scale geometry, not fabrication.
"""
from pathlib import Path
import ast, hashlib, json, math, sys
from collections import defaultdict
from html import escape
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATA = ROOT / 'work/second-grain-live-case2/dist/case2/explore/data'
SOURCE = ROOT / 'work/case2-contour'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name, obj): (HERE/name).write_text(json.dumps(obj, indent=2, allow_nan=False), encoding='utf-8')

# Reuse exactly the independent existing rigid-body point operator without
# importing the full-bench audit's scipy dependency or launching its main.
helper_path = SOURCE/'audit_r03_rigidity.py'
tree = ast.parse(helper_path.read_text(encoding='utf-8'))
point_ast = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'at_point')
namespace = {'np': np}
exec(compile(ast.Module(body=[point_ast], type_ignores=[]), str(helper_path), 'exec'), namespace)
at_point = namespace['at_point']

def area(p): return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1])))/2
def cross2(a,b): return a[0]*b[1]-a[1]*b[0]
def sub(a,b): return [x-y for x,y in zip(a,b)]
def clip(subject, clipper):
    """Independent convex polygon intersection; saved rectangles are CCW."""
    out = subject[:]
    for a,b in zip(clipper,clipper[1:]+clipper[:1]):
        old, out = out, []
        if not old: break
        edge = sub(b,a)
        prev = old[-1]; dp = cross2(edge,sub(prev,a))
        for cur in old:
            dc = cross2(edge,sub(cur,a))
            if (dc>=-1e-9) != (dp>=-1e-9):
                t = dp/(dp-dc)
                out.append([prev[i]+t*(cur[i]-prev[i]) for i in range(2)])
            if dc>=-1e-9: out.append(cur)
            prev,dp = cur,dc
    return out

def edge_distances(p, poly):
    signed=[]; segments=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ab=np.array(sub(b,a)); ap=np.array(sub(p,a)); t=float(ap@ab/(ab@ab))
        signed.append(cross2(ab,ap)/float(np.linalg.norm(ab)))
        segments.append(float(np.linalg.norm(ap-np.clip(t,0,1)*ab)))
    return dict(signed_edge_line_distances_mm=signed,edge_segment_distances_mm=segments,
                minimum_edge_distance_mm=min(segments),inside=bool(min(signed)>=-1e-7))

def rank_result(A):
    s=np.linalg.svd(np.asarray(A),compute_uv=False)
    ranks={str(t):int(sum(s>s[0]*t)) for t in [1e-8,1e-10,1e-12]}
    return dict(shape=list(np.asarray(A).shape),rank_at_relative_tolerances=ranks,
                rank=ranks['1e-10'],nullity=np.asarray(A).shape[1]-ranks['1e-10'],
                singular_values=s.tolist(),stable_rank=len(set(ranks.values()))==1)

def pair_kinematics(points):
    p=np.array(points)/1000; origin=p.mean(axis=0)
    A=np.vstack([at_point(q-origin) for q in p]); out=rank_result(A)
    axis=p[1]-p[0];axis/=np.linalg.norm(axis)
    mode=np.r_[np.cross(axis,origin-p[0]),axis]
    out.update(origin_xyz_m=origin.tolist(),original_pair_axis_xyz=axis.tolist(),
               original_pair_rotation_dofs=mode.tolist(),
               original_pair_rotation_max_residual_m_per_rad=float(np.max(np.abs(A@mode))),
               third_point_velocity_norm_mm_per_rad=float(np.linalg.norm(at_point(p[2]-origin)@mode)*1000) if len(p)==3 else None,
               interpretation='Relative rigid-body equality only; rank does not measure physical stiffness or capacity.')
    return out

def svg_document(terminal,ordinary,sample):
    out=['<svg xmlns="http://www.w3.org/2000/svg" width="1340" height="1050" viewBox="0 0 1340 1050">',
         '<rect width="1340" height="1050" fill="#f4f1e9"/><g font-family="Arial,sans-serif" fill="#243d3a">',
         '<text x="30" y="38" font-size="24" font-weight="bold">Case 2 | actual overlap samples and terminal R03 kinematics</text>',
         '<text x="30" y="65" font-size="14">Working millimetres / geometry-derived dimensions / analytical details, not fabrication or fastener approval</text>']
    def panel(d,x,y,w,h,title,points,triangle=False):
        poly=d['recomputed_overlap_polygon_xz_mm'];lo=np.min(poly,axis=0);hi=np.max(poly,axis=0)
        scale=min((w-115)/(hi[0]-lo[0]),(h-85)/(hi[1]-lo[1]))
        def xy(p): return [x+65+(p[0]-lo[0])*scale,y+h-28-(p[1]-lo[1])*scale]
        def ps(seq):return ' '.join(f'{u:.2f},{v:.2f}' for u,v in seq)
        out.append(f'<text x="{x}" y="{y}" font-size="18" font-weight="bold">{escape(title)}</text>')
        out.append(f'<polygon points="{ps(map(xy,poly))}" fill="#ddd2a4" stroke="#37514c" stroke-width="2"/>')
        p=[xy([v[0],v[2]]) for v in points]
        if triangle:out.append(f'<polygon points="{ps(p)}" fill="#b37a2b25" stroke="#b37a2b" stroke-width="2"/>')
        out.append(f'<line x1="{p[0][0]}" y1="{p[0][1]}" x2="{p[1][0]}" y2="{p[1][1]}" stroke="#a04740" stroke-width="2" stroke-dasharray="5 4"/>')
        for i,(u,v) in enumerate(p):out.append(f'<circle cx="{u}" cy="{v}" r="5" fill="{["#a04740","#a04740","#b37a2b"][i]}"/><text x="{u+8}" y="{v-8}" font-size="13">T{i+1}</text>')
        if triangle:
            v=np.array(points[1])-points[0];q=np.array(points[2]);a=np.array(points[0]);foot=a+v*np.dot(q-a,v)/np.dot(v,v)
            f=xy([foot[0],foot[2]])
            out.append(f'<line x1="{p[2][0]}" y1="{p[2][1]}" x2="{f[0]}" y2="{f[1]}" stroke="#b37a2b" stroke-dasharray="3 3"/>')
        lx=x+65;rx=lx+(hi[0]-lo[0])*scale;by=y+h-12
        out.append(f'<path d="M{lx},{by-5}v10 M{lx},{by}H{rx} M{rx},{by-5}v10" fill="none" stroke="#37514c"/>')
        out.append(f'<text x="{(lx+rx)/2}" y="{by+20}" text-anchor="middle" font-size="12">XZ overlap width {hi[0]-lo[0]:.2f} mm</text>')
        out.append(f'<text x="{x+4}" y="{y+45}" font-size="12">Z span</text><text x="{x+4}" y="{y+62}" font-size="12">{hi[1]-lo[1]:.2f} mm</text>')
    tp=terminal['tie_points_xyz_mm'];op=ordinary['tie_points_xyz_mm']
    panel(terminal,30,108,405,300,'R02 | terminal original pair',tp[:2])
    panel(terminal,465,108,405,300,'R03 | same face + T3',tp,True)
    panel(ordinary,900,108,405,300,'Ordinary | C2CONTACT_0626',op)
    lines=[
      (30,460,f"{terminal['contact_id']} | S001 B01 / B02 | shared area {terminal['recomputed_overlap_area_mm2']:.2f} mm²"),
      (30,484,f"T1–T2 {terminal['pair_spacing_mm']:.2f} mm | pair rank 5/6, 1 free relative rotation | triangle rank 6/6"),
      (30,508,f"T3 lever arm {terminal['triangle_height_mm']:.2f} mm | triangle area {terminal['triangle_area_mm2']:.2f} mm² | minimum edge distance {min(x['overlap_edges']['minimum_edge_distance_mm'] for x in terminal['tie_membership']):.2f} mm"),
      (30,548,'Terminal tie coordinates (X, Y, Z), mm:'),
      *[(30,572+i*23,f"T{i+1}: ({v[0]:.3f}, {v[1]:.3f}, {v[2]:.3f})") for i,v in enumerate(tp)],
      (715,460,f"S040 B02 / B03 | shared area {ordinary['recomputed_overlap_area_mm2']:.2f} mm²"),
      (715,484,f"Pair spacing {ordinary['pair_spacing_mm']:.2f} mm | rank 5/6"),
      (715,508,f"Minimum tie-to-face-edge distance {min(x['overlap_edges']['minimum_edge_distance_mm'] for x in ordinary['tie_membership']):.2f} mm"),
      (715,548,'Ordinary tie coordinates (X, Y, Z), mm:'),
      *[(715,572+i*23,f"T{i+1}: ({v[0]:.3f}, {v[1]:.3f}, {v[2]:.3f})") for i,v in enumerate(op)],
      (30,678,'S039–S041 sample boundary | actual network context'),
      (30,812,f"{sample['member_count']} members | {sample['internal_group_count']} internal contacts / {sample['internal_tie_count']} ties | {sample['boundary_group_count']} contacts / {sample['boundary_tie_count']} ties cross sample boundary"),
      (30,838,'Retained real supports: PAD03 at S040 B01 and PAD04 at S040 B09 (UZ only; no new restraints).'),
      (30,864,'Cross-boundary connections continue to S038 and S042; an isolated crop is not the full bench.'),
      (30,913,'Decision: preserve R03. No evidence here warrants R04 or a new whole-bench/native solve.'),
      (30,939,'Physical hold: fastener layout/product, grain/end/edge rules, slip/rotational stiffness, bearing, withdrawal and pad friction.'),
      (30,974,'All edge distances are geometric measurements only. Timber remains 38.1 × 88.9 mm; no member or stock change.'),
      (30,1000,'Source-bound R03 forces are extracted separately; timber section forces are not individual fastener demands.')]
    for x,y,text in lines:out.append(f'<text x="{x}" y="{y}" font-size="{16 if y==678 else 14}" font-weight="{"bold" if y in [678,913] else "normal"}">{escape(text)}</text>')
    for i,label in enumerate(['S038','S039','S040','S041','S042']):
        x=100+i*248;out.append(f'<rect x="{x}" y="713" width="180" height="60" rx="7" fill="{"#d1e0d7" if i in [1,2,3] else "#e4e3dd"}" stroke="#536b61"/><text x="{x+90}" y="749" font-size="19" text-anchor="middle">{label}</text>')
        if i<4:out.append(f'<path d="M{x+180},743H{x+248}" stroke="#a67b36" stroke-width="4"/>')
    out.append('<rect x="327" y="699" width="710" height="88" rx="10" fill="none" stroke="#395e51" stroke-dasharray="6 4"/></g></svg>')
    (HERE/'case2-samples-dimensioned.svg').write_text('\n'.join(out),encoding='utf-8')

def main():
    gpath=DATA/'case2.json';apath=DATA/'case2-analysis.json'
    page=read(gpath);g=page['geometry'];analysis=read(apath)
    ipath=SOURCE/'analysis-r03/input.json';r=read(ipath)
    prov=analysis['provenance']['primary'];native_path=Path(prov['result_path']);native=read(native_path)
    baseline_path=Path(r['connection_revision']['baseline_input_path']);baseline=read(baseline_path)
    geom_path=Path(r['binding']['geometry_path']);published_geom=read(geom_path)
    kin_path=Path(analysis['kinematic_audit']['path']);kin=read(kin_path)
    paths=[gpath,apath,ipath,Path(prov['input_path']),native_path,baseline_path,geom_path,kin_path,helper_path,
           SOURCE/'analysis-r03/connection-corrections.json']
    hashes={str(p):sha(p) for p in paths}
    assert sha(ipath)==prov['input_sha256']==sha(prov['input_path'])==native['input_sha256']
    assert sha(native_path)==prov['result_sha256']
    assert sha(geom_path)==r['binding']['geometry_sha256'] and g==published_geom
    assert sha(kin_path)==analysis['kinematic_audit']['sha256']
    assert kin['current']['input_sha256']==sha(ipath) and kin['current']['nullity']==0
    assert native['analysis_binding']==r['binding'] and native['run_id']==r['run_id']==analysis['run_id']
    assert sha(baseline_path)==r['connection_revision']['baseline_input_sha256']
    for key in ['members','supports','loads','load_cases','properties','material_basis']:
        assert r[key]==baseline[key],key
    for key in ['nodes','elements','connection_ties']:
        assert r[key][:len(baseline[key])]==baseline[key],key
    assert len(r['connection_ties'])-len(baseline['connection_ties'])==4
    parts={p['part_id']:p for p in g['parts']};members={m['member_id']:m for m in r['members']}
    groups=defaultdict(list)
    for t in r['connection_ties']: groups[t['contact_id']].append(t)
    raw_contacts={tuple(sorted(c['part_ids'])):c for c in g['contacts']}
    def detail(cid):
        ties=sorted(groups[cid],key=lambda t:t['id']);ids=ties[0]['part_ids'];ps=[parts[x] for x in ids]
        raw=raw_contacts[tuple(sorted(ids))];poly=clip(ps[0]['polygon_xz_mm'],ps[1]['polygon_xz_mm'])
        a=area(poly);assert abs(a-raw['projected_overlap_area_mm2'])<1e-6
        points=[t['xyz_mm'] for t in ties];rows=[]
        for t in ties:
            q=t['xyz_mm'];xz=[q[0],q[2]];edges=edge_distances(xz,poly);own=[]
            for p in ps:
                tr=p['source_coordinate_transform'];delta=np.array(q)-tr['origin_mm']
                u=float(delta@tr['longitudinal_direction']);v=float(delta@tr['width_direction'])
                own.append(dict(member_id=p['part_id'],inside_projected_member=edge_distances(xz,p['polygon_xz_mm'])['inside'],
                                longitudinal_station_mm=u,width_station_mm=v,
                                geometric_end_distances_mm=[u,p['blank_length_mm']-u],
                                geometric_long_edge_distances_mm=[v,88.9-v],
                                on_broad_face=bool(min(abs(q[1]-p['y_mm']),abs(q[1]-p['y_mm']-p['thickness_mm']))<1e-7)))
            assert edges['inside'] and all(x['inside_projected_member'] and x['on_broad_face'] for x in own)
            assert np.allclose(np.array(r['nodes'][t['node']]['xyz_m'])*1000,q,atol=1e-9,rtol=0)
            rows.append(dict(tie_id=t['id'],node_id=t['node'],xyz_mm=q,overlap_edges=edges,member_membership=own))
        out=dict(contact_id=cid,part_ids=ids,tie_count=len(ties),tie_points_xyz_mm=points,
                 recomputed_overlap_polygon_xz_mm=poly,source_overlap_polygon_xz_mm=raw['overlap_polygon_xz_mm'],
                 recomputed_overlap_area_mm2=a,source_overlap_area_mm2=raw['projected_overlap_area_mm2'],
                 shared_face_y_mm=raw['contact_y_mm'],broad_face_gap_mm=raw['broad_face_gap_mm'],
                 physical_members=[dict(member_id=p['part_id'],rib_id=p['rib_id'],polygon_xz_mm=p['polygon_xz_mm'],y_mm=p['y_mm'],thickness_mm=p['thickness_mm'],blank_length_mm=p['blank_length_mm'],section_mm=p['source_section_mm']) for p in ps],
                 tie_membership=rows,pair_spacing_mm=math.dist(points[0],points[1]),
                 pair_kinematics=pair_kinematics(points[:2]),
                 member_contact_degrees={pid:sum(pid in ts[0]['part_ids'] for ts in groups.values()) for pid in ids})
        assert out['pair_kinematics']['rank']==5 and out['pair_kinematics']['nullity']==1
        assert out['pair_kinematics']['original_pair_rotation_max_residual_m_per_rad']<1e-12
        if len(points)==3:
            height=float(np.linalg.norm(np.cross(np.array(points[1])-points[0],np.array(points[2])-points[0]))/out['pair_spacing_mm'])
            out.update(triangle_height_mm=height,triangle_area_mm2=height*out['pair_spacing_mm']/2,triangle_kinematics=pair_kinematics(points))
            assert out['triangle_kinematics']['rank']==6 and out['triangle_kinematics']['nullity']==0
            assert abs(out['triangle_kinematics']['third_point_velocity_norm_mm_per_rad']-height)<1e-8
        return out
    terminal=detail('C2CONTACT_0001');ordinary=detail('C2CONTACT_0626')
    assert terminal['part_ids']==['C2O_S001_B01','C2O_S001_B02']
    assert ordinary['part_ids']==['C2O_S040_B02','C2O_S040_B03']
    terminal_ids=set(terminal['part_ids'])
    terminal_boundary=[dict(contact_id=cid,part_ids=ts[0]['part_ids'],tie_ids=[t['id'] for t in ts],tie_points_xyz_mm=[t['xyz_mm'] for t in ts]) for cid,ts in groups.items() if set(ts[0]['part_ids'])&terminal_ids and not set(ts[0]['part_ids'])<=terminal_ids]
    terminal['crop_boundary']=dict(member_count=2,internal_group_count=1,internal_tie_count=3,
         boundary_group_count=len(terminal_boundary),boundary_tie_count=sum(len(c['tie_ids']) for c in terminal_boundary),
         boundary_contacts=terminal_boundary,actual_supports=[s for s in r['supports'] if s['member_id'] in terminal_ids],
         interpretation='S001 B01 is the terminal leaf with one contact; its neighbor S001 B02 continues into three other contacts. No terminal clamp or new support is introduced.')
    sample_ids={p['part_id'] for p in g['parts'] if p['rib_id'] in ['S039','S040','S041']}
    internal=[];boundary=[]
    for cid,ts in groups.items():
        ids=set(ts[0]['part_ids']);row=dict(contact_id=cid,part_ids=ts[0]['part_ids'],tie_ids=[t['id'] for t in ts],tie_points_xyz_mm=[t['xyz_mm'] for t in ts])
        if ids<=sample_ids:internal.append(row)
        elif ids&sample_ids:boundary.append(row)
    actual_supports=[s for s in r['supports'] if s['member_id'] in sample_ids]
    sample=dict(station_ids=['S039','S040','S041'],member_ids=sorted(sample_ids),member_count=len(sample_ids),
                internal_group_count=len(internal),internal_tie_count=sum(len(c['tie_ids']) for c in internal),
                boundary_group_count=len(boundary),boundary_tie_count=sum(len(c['tie_ids']) for c in boundary),
                internal_contacts=internal,boundary_contacts=boundary,actual_supports=actual_supports,
                external_neighbor_member_ids=sorted({pid for c in boundary for pid in c['part_ids'] if pid not in sample_ids}),
                boundary_interpretation='Crop retains connections to S038 and S042; full-bench response is not an isolated coupon response. No cut-boundary clamp or new support is imposed.')
    selected=sample_ids|set(terminal['part_ids']);force_rows=[];demands=[]
    for c in analysis['load_cases']:
        cid=c['id'];assert c['results_valid'] and native['response_checks'][cid]['force_balance_pass'] and native['response_checks'][cid]['moment_balance_pass']
        raw=native['cases'][cid];saved={(f['element_id'],f['station_fraction']):f for f in c['results']['member_forces'] if f['strip_id'] in selected}
        compare_count=0
        for pid in selected:
            for e in raw['member_forces'][pid]:
                for station,f,m in zip(e['stations'],e['force_kN'],e['moment_kNm']):
                    row=saved[(e['analysis_element_id'],station)]
                    expected=np.r_[np.array(f)*1000,np.array(m)*1e6]
                    assert np.allclose(expected,[row[k] for k in ['N_N','Vy_N','Vz_N','T_Nmm','My_Nmm','Mz_Nmm']],rtol=1e-12,atol=1e-8)
                    compare_count+=1;force_rows.append(dict(load_case=cid,**row))
        relevant=[x for x in c['results']['reactions'] if any(x['node_id']==s['node'] for s in actual_supports)]
        for row in relevant:
            rr=next(x for x in raw['reactions'] if x['node']==row['node_id'])
            assert np.allclose(row['force_N'],np.array(rr['force_kN'])*1000,rtol=1e-12,atol=1e-8)
        envelopes={}
        for label,ids in [('terminal_pair',set(terminal['part_ids'])),('ordinary_pair',set(ordinary['part_ids'])),('S039_S041',sample_ids)]:
            subset=[f for f in saved.values() if f['strip_id'] in ids]
            envelopes[label]={k:max(subset,key=lambda f:abs(f[k])) for k in ['N_N','Vy_N','Vz_N','T_Nmm','My_Nmm','Mz_Nmm']}
        demands.append(dict(load_case=cid,source_rows_cross_checked=compare_count,member_force_envelopes=envelopes,
                            sample_pad_reactions=relevant,full_bench_balance=c['results']['reaction_balance'],
                            full_bench_friction_demand=c['results']['unanchored_bearing_check'],
                            scope='Timber element-local section forces and actual support reactions from saved R03; no tie/fastener force output is present in the native result.'))
    report=dict(schema='CASE2_ACTUAL_NODE_SAMPLE_VALIDATION/1',status='PASS',run_id=r['run_id'],
                geometry_id=g['geometry_id'],allocation_run_id=r['binding']['allocation_run_id'],
                source_hashes=hashes,full_bench_counts=dict(members=len(r['members']),contacts=len(groups),ties=len(r['connection_ties']),supports=len(r['supports'])),
                terminal_sample=terminal,ordinary_sample=ordinary,ordinary_station_sample=sample,saved_demand_extraction=demands,
                reused_independent_kinematic_function=dict(path=str(helper_path),sha256=sha(helper_path),function='at_point',method='Exact AST extraction; numpy SVD at relative tolerances 1e-8, 1e-10, 1e-12'),
                existing_full_assembly_certificate=dict(source=str(kin_path),sha256=sha(kin_path),rank=kin['current']['rank'],nullity=kin['current']['nullity'],rank_at_relative_tolerances=kin['current']['rank_at_relative_tolerances'],rerun=False),
                controlled_change_decision=dict(revision='RETAIN_R03',r04_warranted=False,new_native_solve=False,geometry_changed=False,allocation_rerun=False,
                    reason='Actual face membership and noncollinear terminal triangle pass. Existing R03 native and full-assembly certificate remain source-bound; no corrected analysis input is justified.',
                    physical_status='HOLD_FOR_CONNECTION_AND_SUPPORT_SPECIFICATION',
                    required_evidence=['Measured member scale and condition/grade','Fastener type/diameter/count, hole and assembly specification','Grain-dependent end/edge spacing and splitting/bearing/withdrawal checks','Connection slip and rotational stiffness or a substantiated mechanical model','Pad bearing and friction evidence'],
                    next_revision_gate='A demonstrated physical-model discrepancy or specified/calibrated connection law may justify a controlled R04 comparison; missing physical data alone does not justify invented springs or another arbitrary native solve.'),
                source_records_modified=False,solver_launched=False,fastener_capacity_verified=False,
                test_summary=['R03 input/result/geometry/native bindings and SHA-256 verified','Current input members/supports/loads/materials equal R02 baseline; exactly four ties added','Independent rectangle intersection reproduces saved overlap areas','All actual tie nodes coincide with saved coordinates and lie on both member broad faces','Geometric edge/end distances computed without design-rule pass claims','Actual two-point rank 5 and residual rotation verified; terminal three-point rank 6 at three tolerances','Terminal residual rotation at T3 equals geometric transverse lever arm','S039-S041 internal and cross-boundary contact census; only actual PAD03/PAD04 retained','Extracted element-local force rows and pad reactions cross-checked against native unit conversion','All read source hashes rechecked unchanged after extraction'])
    save('case2-node-samples.json',report);save('case2-sample-force-rows.json',dict(source_result_sha256=sha(native_path),frame='ELEMENT_LOCAL',rows=force_rows,not_fastener_forces=True))
    svg_document(terminal,ordinary,sample)
    assert all(sha(p)==h for p,h in hashes.items()),'Source changed during validation'
    save('artifact-manifest.json',dict(source_records_unchanged=True,files={p.name:sha(p) for p in [Path(__file__),HERE/'case2-node-samples.json',HERE/'case2-sample-force-rows.json',HERE/'case2-samples-dimensioned.svg']}))
    (HERE/'reproduce-and-interpret.txt').write_text(
        'Run: python -X utf8 validate_case2_samples.py\nRequires: Python and numpy.\n'
        'Reads original source paths recorded in case2-node-samples.json; writes only to this folder.\n'
        'No native Karamba, geometry, allocation, stock, video, website or E: source edits.\n\n'
        'Terminal C2CONTACT_0001: the original R02 T1/T2 remain unchanged. Their relative rigid-body constraint rank is 5/6. The actual R03 T3 raises rank to 6/6 at all three tested tolerances.\n'
        'An ordinary two-point contact still has one local relative rotation; this alone is not a whole-bench mechanism. The saved R03 full-assembly certificate has rank 4296/4296.\n'
        'S039-S041 retains 27 members, 40 internal groups and 16 cross-boundary groups to S038/S042. PAD03 and PAD04 are its only existing support nodes; they restrain UZ. No new cut-boundary clamps are assumed.\n'
        'Saved force output contains timber element-local section forces only. These are not individual tie/fastener loads, and section extrema may occur at different elements/stations.\n'
        'RETAIN_R03: actual geometry and idealized kinematics pass. Physical connection and support verification remains on hold pending fastener/layout, grain-dependent distances, measured stiffness/slip and capacities/friction. Do not invent springs or claim fabrication approval.\n'
        'case2-samples-dimensioned.svg is the canonical vector. Its PNG is a visual-QA convenience export.\n',encoding='utf-8')
    print(json.dumps(dict(status='PASS',terminal_area_mm2=terminal['recomputed_overlap_area_mm2'],triangle_height_mm=terminal['triangle_height_mm'],triangle_area_mm2=terminal['triangle_area_mm2'],ordinary_area_mm2=ordinary['recomputed_overlap_area_mm2'],sample_members=len(sample_ids),internal_groups=len(internal),boundary_groups=len(boundary),force_rows_cross_checked=len(force_rows),decision='RETAIN_R03',outputs=str(HERE)),indent=2))

if __name__=='__main__':main()
