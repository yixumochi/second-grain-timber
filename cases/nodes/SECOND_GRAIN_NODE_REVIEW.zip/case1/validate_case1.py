"""Local digital machining experiment; never changes the accepted geometry or analysis.

Pure geometry: convex polygon clipping and separating-axis tests. All units mm.
The candidate is a union of retained convex prisms, not merely a clash annotation.
"""
from pathlib import Path
import json, hashlib, math, itertools, copy
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
ASSETS=ROOT/'work/second-grain-live-case2/dist/assets'
PATHS={'geometry':ASSETS/'analysis/members.json','analysis':ASSETS/'analysis/analysis.json','allocation':ASSETS/'update/allocation.json'}
GAP=2.0 # Explicit fit-screen experiment, NOT a timber movement or fabrication tolerance standard.
EPS=1e-7

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):p.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def signed_area(p):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))/2
def area(p):return abs(signed_area(p)) if len(p)>=3 else 0.
def ccw(p):return p if signed_area(p)>0 else p[::-1]
def hull(points):
    p=sorted(set(tuple(round(float(v),9) for v in q) for q in points))
    def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lo=[];hi=[]
    for q in p:
        while len(lo)>=2 and cross(lo[-2],lo[-1],q)<=EPS:lo.pop()
        lo.append(q)
    for q in reversed(p):
        while len(hi)>=2 and cross(hi[-2],hi[-1],q)<=EPS:hi.pop()
        hi.append(q)
    return [list(q) for q in lo[:-1]+hi[:-1]]
def edges(p):return list(zip(p,p[1:]+p[:1]))
def halfplane(p,a,b,keep_inside=True):
    n=[-(b[1]-a[1]),b[0]-a[0]];sgn=1 if keep_inside else -1
    def d(q):return sgn*dot(n,[q[0]-a[0],q[1]-a[1]])
    out=[]
    for q,r in edges(p):
        dq,dr=d(q),d(r)
        if dq>=-EPS:out.append(q)
        if (dq<0)!=(dr<0):
            t=dq/(dq-dr);out.append([q[i]+t*(r[i]-q[i]) for i in range(2)])
    return hull(out) if len(out)>=3 else []
def intersect(p,q):
    for a,b in edges(q):
        p=halfplane(p,a,b)
        if not p:break
    return p
def difference(p,q):
    # Every emitted convex piece lies outside one clip edge. Their interiors are disjoint.
    out=[]
    for a,b in edges(q):
        outside=halfplane(p,a,b,False)
        if area(outside)>EPS:out.append(outside)
        p=halfplane(p,a,b)
        if not p:break
    return out
def vertices(box):
    return [[box['center'][j]+sum(s[i]*box['half'][i]*box['axes'][i][j] for i in range(3)) for j in range(3)] for s in itertools.product([-1,1],repeat=3)]
def prism(p,y):return {'polygon_xz_mm':p,'y_interval_mm':y}
def prism_vertices(p):return [[x,y,z] for y in p['y_interval_mm'] for x,z in p['polygon_xz_mm']]
def box_prism(b):
    v=vertices(b);return prism(hull([[q[0],q[2]] for q in v]),[min(q[1] for q in v),max(q[1] for q in v)])
def sep_prism_box(p,b):
    # 3D SAT; negative => separated, zero => touching, positive => overlap.
    pv=np.array(prism_vertices(p));bv=np.array(vertices(b));
    pedges=[np.array([0.,1.,0.])]+[np.array([r[0]-q[0],0.,r[1]-q[1]]) for q,r in edges(p['polygon_xz_mm'])]
    normals=[np.array([0.,1.,0.])]+[np.cross(e,pedges[0]) for e in pedges[1:]]
    bedges=[np.array(a) for a in b['axes']]
    axes=normals+bedges+[np.cross(a,c) for a in pedges for c in bedges]
    best=1e30;axis=None
    for n in axes:
        length=np.linalg.norm(n)
        if length<EPS:continue
        n=n/length;a=pv@n;c=bv@n
        overlap=min(a.max(),c.max())-max(a.min(),c.min())
        if overlap<best:best=float(overlap);axis=n.tolist()
    return best,axis
def extent(b):
    v=np.array(vertices(b));return [v.min(axis=0).tolist(),v.max(axis=0).tolist()]
def rounder(obj):
    if isinstance(obj,float):return round(obj,8)
    if isinstance(obj,list):return [rounder(v) for v in obj]
    if isinstance(obj,dict):return {k:rounder(v) for k,v in obj.items()}
    return obj

def main():
    hashes={k:sha(v) for k,v in PATHS.items()}
    saved={k:json.loads(v.read_text(encoding='utf-8-sig')) for k,v in PATHS.items()}
    members=saved['geometry']['members'];byparent={m['parent_member_id']:m for m in members if m['role']!='WALL_CLADDING'}
    alloc={p['part_id']:p for bar in saved['allocation']['cut_bars'] for p in bar['pieces']}
    reported=saved['analysis']['result']['physical_joint_review']['existing_interferences']
    affected={r['members'][1] for r in reported};prisms={};rows=[];patches=[];removed_total=0
    for reported_row in reported:
        brace,back=[byparent[k] for k in reported_row['members']]
        b=brace['box'];v=back['box'];before=box_prism(v);bp=box_prism(b)
        side='NORTH' if 'NORTH' in brace['parent_member_id'] else 'SOUTH'
        normal_sign=1 if side=='NORTH' else -1
        # Expanded brace envelope in XZ; no corner relief/cutter radius is assumed.
        cutter_box=copy.deepcopy(b);cutter_box['half'][0]+=GAP;cutter_box['half'][1]+=GAP
        cutterpoly=box_prism(cutter_box)['polygon_xz_mm']
        notch=intersect(before['polygon_xz_mm'],cutterpoly)
        clash=intersect(before['polygon_xz_mm'],bp['polygon_xz_mm'])
        by=before['y_interval_mm'];ry=bp['y_interval_mm']
        plane=ry[0]-GAP if normal_sign==1 else ry[1]+GAP
        cut_y=[plane,by[1]] if normal_sign==1 else [by[0],plane]
        core_y=[by[0],plane] if normal_sign==1 else [plane,by[1]]
        retained=[prism(before['polygon_xz_mm'],core_y)]+[prism(p,cut_y) for p in difference(before['polygon_xz_mm'],cutterpoly)]
        prisms[back['part_id']]=retained
        oldvol=area(before['polygon_xz_mm'])*(by[1]-by[0]);removed=area(notch)*(cut_y[1]-cut_y[0]);newvol=sum(area(p['polygon_xz_mm'])*(p['y_interval_mm'][1]-p['y_interval_mm'][0]) for p in retained)
        assert abs(oldvol-removed-newvol)<0.01
        before_pen=sep_prism_box(before,b)[0];after_tests=[sep_prism_box(p,b)[0] for p in retained]
        assert before_pen>EPS and all(p<-EPS for p in after_tests)
        support=saved['analysis']['input']['members'];support=next(q for q in support if q['member_id']==back['parent_member_id'])['host_ids']
        u=v['axes'][0];start=[v['center'][j]-v['half'][0]*u[j] for j in range(3)]
        station=[dot([x-start[0],0,z-start[2]],u) for x,z in notch]
        span=[min(station),max(station)];source=alloc[back['part_id']]
        row={'node_id':f'C1_{side}_{back["parent_member_id"].split(side+"_")[1]}','brace_member_id':brace['parent_member_id'],'brace_part_id':brace['part_id'],'backing_member_id':back['parent_member_id'],'backing_part_id':back['part_id'],'source_stock_id':back['stock_id'],'source_material_id':back['material_id'],'source_url':source['source'],'source_interval_mm':source['source_interval_mm'],'machining_source_span_mm':[source['source_interval_mm'][0]+q for q in span],'machining_member_span_mm':span,'reported_penetration_mm':reported_row['new_penetration_mm'],'recomputed_penetration_mm':before_pen,'clash_projected_area_mm2':area(clash),'clash_volume_mm3':area(clash)*min(ry[1]-ry[0],by[1]-by[0]),'candidate_machining':{'operation':'SUBTRACT_CONVEX_PRISM_FROM_BACKING_ONLY','removed_polygon_xz_mm':notch,'removed_y_interval_mm':cut_y,'depth_mm':cut_y[1]-cut_y[0],'normal_clearance_to_brace_mm':GAP,'lateral_clearance_to_brace_edge_mm':GAP,'cutter_radius_mm':None,'cutter_status':'IDEAL_SHARP_GEOMETRY_ONLY; router/tool access and corner relief untested'},'remaining_wall_normal_depth_mm':core_y[1]-core_y[0],'removed_volume_mm3':removed,'before_volume_mm3':oldvol,'after_volume_mm3':newvol,'candidate_sat_penetrations_mm':after_tests,'all_retained_solids_separate_from_brace':True,'bearing_host_ids':support,'before_box':v,'after_retained_convex_prisms':retained,'brace_box_unchanged':b}
        rows.append(row);removed_total+=removed
        # Quantify removed OUTER face contact to cladding, without crediting brace replacement support.
        outer=by[1] if normal_sign==1 else by[0]
        for clad in members:
            if clad['role']!='WALL_CLADDING':continue
            cp=box_prism(clad['box']);cy=cp['y_interval_mm']
            if abs((cy[0] if normal_sign==1 else cy[1])-outer)>EPS:continue
            original_area=area(intersect(before['polygon_xz_mm'],cp['polygon_xz_mm']))
            loss=area(intersect(notch,cp['polygon_xz_mm']))
            if loss>EPS:patches.append({'backing_part_id':back['part_id'],'cladding_part_id':clad['part_id'],'cladding_member_id':clad['parent_member_id'],'contact_y_mm':outer,'before_contact_area_mm2':original_area,'lost_contact_area_mm2':loss,'remaining_contact_area_mm2':original_area-loss,'relative_contact_area_loss':loss/original_area,'replacement_support_credited':False})
    # Screen every changed member against all other original parts. A subtractive candidate cannot add a collision.
    pairs=[]
    for row in rows:
        pid=row['backing_part_id'];old=box_prism(row['before_box']);ret=prisms[pid]
        for other in members:
            if other['part_id']==pid:continue
            oldpen=sep_prism_box(old,other['box'])[0]
            newpen=max(sep_prism_box(p,other['box'])[0] for p in ret)
            if oldpen>=-EPS or newpen>=-EPS:pairs.append({'changed_part_id':pid,'other_part_id':other['part_id'],'other_member_id':other['parent_member_id'],'before_sat_overlap_mm':oldpen,'after_sat_overlap_mm':newpen,'new_interference':oldpen<=EPS and newpen>EPS,'interpretation':'SAT overlap class only; an intended joint may overlap in the rectangular baseline.'})
    assert not any(p['new_interference'] for p in pairs)
    # Reject tempting translation alternatives against actual saved posts and cladding.
    alternatives=[]
    for side in ['NORTH','SOUTH']:
        brace=byparent['BRACE_'+side];sign=1 if side=='NORTH' else -1
        for name,offset in [('OUTWARD_CLEAR_BACKING',sign*40.1),('INWARD_CLEAR_BACKING',-sign*90.9)]:
            moved=copy.deepcopy(brace['box']);moved['center'][1]+=offset
            pp=box_prism(moved);clashes=[];post_tests=[]
            host_ids=next(m for m in saved['analysis']['input']['members'] if m['member_id']==brace['parent_member_id'])['host_ids']
            for other in members:
                if other['part_id']==brace['part_id']:continue
                overlap=sep_prism_box(pp,other['box'])[0]
                if overlap>EPS:clashes.append({'part_id':other['part_id'],'member_id':other['parent_member_id'],'role':other['role'],'sat_overlap_mm':overlap})
                if other['parent_member_id'] in host_ids:post_tests.append({'host_member_id':other['parent_member_id'],'signed_sat_overlap_mm':overlap,'contact_class':'INTERPENETRATION' if overlap>EPS else 'GAP' if overlap<-EPS else 'TOUCHING'})
            alternatives.append({'brace_member_id':brace['parent_member_id'],'test':name,'translation_y_mm':offset,'status':'REJECT_AS_DROP_IN_REPAIR','post_bearing_tests':post_tests,'interferences':clashes,'reason':'Outward move loses original post contact and enters cladding; inward move interpenetrates post solids. No new eccentric supports or connector capacities are assumed.'})
    # Check mathematical 2 mm margin under explicitly labelled hypothetical relative closure.
    tolerance=[{'relative_closure_mm':v,'remaining_normal_gap_mm':GAP-v,'open_gap':GAP-v>EPS} for v in [0.,.5,1.,2.,3.]]
    candidate={'schema':'CASE1_LOCAL_CSG_CANDIDATE/1','status':'DIGITAL_CANDIDATE_NOT_PROMOTED','geometry_revision_base':saved['analysis']['provenance']['geometry_revision'],'immutable_base_geometry_sha256':hashes['geometry'],'units':'mm','unchanged_part_ids':[m['part_id'] for m in members if m['part_id'] not in prisms],'modified_parts':[{'part_id':r['backing_part_id'],'parent_member_id':r['backing_member_id'],'before_box':r['before_box'],'subtract_prism':prism(r['candidate_machining']['removed_polygon_xz_mm'],r['candidate_machining']['removed_y_interval_mm']),'retained_prisms':r['after_retained_convex_prisms']} for r in rows],'load_capacity_or_connector_design':False,'accepted_geometry_modified':False}
    dump(HERE/'candidate-geometry.json',rounder(candidate))
    source_records=[{'role':k,'path':str(p),'sha256_before':hashes[k],'sha256_after':sha(p),'unchanged':hashes[k]==sha(p)} for k,p in PATHS.items()]
    assert all(r['unchanged'] for r in source_records)
    ratio=48.8/88.9
    report={'schema':'CASE1_DIGITAL_NODE_VALIDATION/1','date':'2026-10-07','status':'GEOMETRIC_CLASHES_CLEARED_IN_LOCAL_CANDIDATE_ONLY_HOLD_PROMOTION','method':'Convex XZ clipping, exact prismatic volume accounting, 3D separating-axis collision screening. Saved OBB geometry, not physical measurement.','source_records':source_records,'baseline':saved['analysis']['provenance'],'counts':{'baseline_installed_parts':len(members),'changed_backing_parts':len(rows),'unchanged_braces':2,'target_clashes_before':len(rows),'target_clashes_after':0,'changed_vs_all_pair_tests':len(rows)*(len(members)-1),'new_interferences':0,'lost_cladding_contact_patches':len(patches)},'fit_screen_gap_mm':GAP,'gap_basis':'An explicit 2 mm digital fit-screen value, not a validated construction tolerance; measured warp, moisture change and tool tolerance absent.','nodes':rows,'contact_losses':patches,'tolerance_sensitivity':tolerance,'stock_consequences':{'new_source_bars':0,'new_cut_parts':0,'cut_lengths_changed':False,'source_intervals_changed':False,'extra_groove_operations':6,'removed_volume_mm3':removed_total,'removed_volume_litre':removed_total/1e6,'source_cut_kerf_accounting_unchanged':True,'candidate_machining_waste_accounted_separately':True,'physical_remachining_reversible':False,'digital_candidate_reversible':True},'section_consequences':{'backing_original_wall_normal_depth_mm':88.9,'backing_minimum_remaining_depth_mm':48.8,'other_section_dimension_mm':38.1,'minimum_remaining_area_mm2':48.8*38.1,'area_ratio':ratio,'one_bending_inertia_ratio':ratio,'other_bending_inertia_ratio':ratio**3,'interpretation':'Local rectangular residual section only. Stress concentrations, shear, splitting, grain defects, connection effects and notch design remain unchecked.'},'preservation':{'brace_boxes_and_post_bearings_unchanged':True,'enclosure_external_envelope_unchanged':True,'no_added_supports_or_fasteners':True,'no_new_source_parts':True,'local_cladding_bearing_contact_reduced':True,'baseline_files_unchanged':True},'promotion_decision':{'geometry':'HOLD: retain reversible digital candidate; do not replace accepted geometry.','analysis':'HOLD: saved full-section backing and load-bearing assumptions do not describe this machined candidate. No MILP/Karamba rerun performed.','reason':'Clashes clear geometrically but local backing area falls 45.11%, one second moment falls 83.46%, and cladding face contact is removed locally. Physical fit plus competent notch/connection and load-path review must choose a defensible detail before rerun.','rerun_if_detail_is_accepted':['Bind six explicit groove geometries and source machining operations.','Model reduced backing sections and revised cladding bearings/loads.','Keep brace/post bearings unless an explicitly justified redesign changes them.','Then rerun the affected structural cases and compare; no full allocation MILP is implied by these unchanged stock intervals.']},'physical_test_status':'NOT_PERFORMED','unverified':['No fastener product, diameter, capacity or stiffness established.','No cutter radius, tool access, grain condition, moisture movement or assembly force measured.','No brace-to-cladding bearing credited to compensate for backing contact loss.','The ideal sharp groove is a geometry experiment, not a fabrication drawing.'],'contact_screen':pairs}
    report['rejected_translation_tests']=alternatives
    dump(HERE/'validation.json',rounder(report));draw(report);export_sample(report)
    dump(HERE/'summary.json',{k:report[k] for k in ['schema','status','counts','stock_consequences','section_consequences','preservation','promotion_decision','physical_test_status']})
    print(json.dumps({k:report[k] for k in ['status','counts','stock_consequences','section_consequences']},indent=2))

def draw(report):
    from html import escape
    r=next(r for r in report['nodes'] if r['backing_member_id']=='WALL_STUD_NORTH_1')
    s=['<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="1080" viewBox="0 0 1500 1080">','<rect width="1500" height="1080" fill="#fbfaf7"/>','<style>text{font-family:Arial,sans-serif;fill:#223237}.title{font-size:30px;font-weight:bold}.sub{font-size:17px}.label{font-size:15px}.tiny{font-size:13px}.dim{stroke:#33454a;stroke-width:1;fill:none}.cut{fill:#df855f;fill-opacity:.6;stroke:#aa4825;stroke-width:1.4}</style>']
    def txt(x,y,t,cls='label'):s.append(f'<text x="{x}" y="{y}" class="{cls}">{escape(t)}</text>')
    def rect(x,y,w,h,fill,stroke='#33454a'):s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}"/>')
    def line(x,y,X,Y,color='#33454a'):s.append(f'<line x1="{x}" y1="{y}" x2="{X}" y2="{Y}" stroke="{color}"/>')
    def dim(x,y,X,Y,label,tx,ty):line(x,y,X,Y);line(x-4,y-4,x+4,y+4);line(X-4,Y-4,X+4,Y+4);txt(tx,ty,label,'tiny')
    txt(45,52,'CASE 1 / SIX CROSSINGS — DIGITAL GROOVE SAMPLE','title')
    txt(45,82,'Saved geometry GEOM_6619b278297dc9d7  |  dimensions in mm  |  2 mm illustrative fit gap  |  NOT FOR FABRICATION','sub')
    txt(45,121,'Representative: BRACE_NORTH × WALL_STUD_NORTH_1','sub')
    txt(45,148,'Brace 111576_001::P01  /  Backing 111576_041::P02','label')
    # Local elevation, in actual XZ dimensions.
    cx,cz=1180.,r['brace_box_unchanged']['center'][2]+(1180-r['brace_box_unchanged']['center'][0])*r['brace_box_unchanged']['axes'][0][2]/r['brace_box_unchanged']['axes'][0][0]
    x0,z0=cx-150,cz-160;scale=1.45
    def poly(p,fill,stroke='#33454a',opacity=1):
        pts=' '.join(f'{70+(x-x0)*scale:.3f},{655-(z-z0)*scale:.3f}' for x,z in p)
        s.append(f'<polygon points="{pts}" fill="{fill}" fill-opacity="{opacity}" stroke="{stroke}"/>')
    crop=[[cx-150,cz-160],[cx+150,cz-160],[cx+150,cz+160],[cx-150,cz+160]]
    back=box_prism(r['before_box']);br=box_prism(r['brace_box_unchanged']);notch=r['candidate_machining']['removed_polygon_xz_mm']
    poly(intersect(back['polygon_xz_mm'],crop),'#d9c4a6');poly(intersect(br['polygon_xz_mm'],crop),'#8da6a0',opacity=.65);poly(notch,'#df855f',opacity=.75)
    txt(70,183,'A — NORTH WALL ELEVATION (local crop)','sub')
    txt(70,690,'Orange = removed backing footprint, expanded 2 mm from brace','tiny')
    dim(260,674,315,674,'38.1 backing width',227,667)
    txt(70,715,f"Groove member station {r['machining_member_span_mm'][0]:.2f}–{r['machining_member_span_mm'][1]:.2f}",'label')
    txt(70,740,f"Source station {r['machining_source_span_mm'][0]:.2f}–{r['machining_source_span_mm'][1]:.2f}",'label')
    txt(610,183,'B — SECTION THROUGH GROOVE / Y DIRECTION','sub')
    # Section at station within complete footprint. y rendered horizontally.
    sy=4.3;origin=645;yb=1219.2
    def yy(v):return origin+(v-yb)*sy
    rect(yy(1219.2),235,88.9*sy,74,'#d9c4a6')
    rect(yy(1270),253,38.1*sy,39,'#8da6a0')
    txt(610,219,'BEFORE: overlapping solids, penetration 38.1','label')
    txt(610,362,'CANDIDATE: subtract groove from backing only','label')
    rect(yy(1219.2),380,48.8*sy,74,'#d9c4a6')
    rect(yy(1270),398,38.1*sy,39,'#8da6a0')
    s.append(f'<rect x="{yy(1268)}" y="380" width="{40.1*sy}" height="74" fill="none" stroke="#aa4825" stroke-dasharray="5 5"/>')
    rect(yy(1308.1),380,38.1*sy,74,'#eee6d7')
    txt(1112,481,'Cladding (unchanged)','tiny')
    dim(yy(1219.2),507,yy(1268),507,'48.8 residual',yy(1219.2)+25,529)
    dim(yy(1268),551,yy(1308.1),551,'40.1 groove depth',yy(1268)+10,572)
    dim(yy(1270),478,yy(1308.1),478,'38.1 brace',yy(1270)+35,499)
    line(yy(1269),394,yy(1269)-20,338);txt(yy(1269)-58,329,'2.0 gap','tiny')
    txt(610,611,'Backing is locally reduced from 38.1 × 88.9 to 38.1 × 48.8.','label')
    txt(610,638,'Area ratio 0.549; bending inertia ratios 0.549 / 0.165.','label')
    txt(610,665,'Outer backing contact to cladding is locally removed.','label')
    txt(610,692,'No brace-to-cladding load transfer or fastener capacity is credited.','label')
    txt(45,792,'SIX-LOCATION CHECK / SAME SUBTRACTIVE OPERATION','sub')
    cols=[45,380,610,885,1120]
    for x,t in zip(cols,['BACKING MEMBER','PART ID','SOURCE MACHINING SPAN','BEFORE / AFTER','NORMAL GAP']):txt(x,821,t,'tiny')
    for i,q in enumerate(report['nodes']):
        y=850+26*i
        vals=[q['backing_member_id'],q['backing_part_id'],f"{q['machining_source_span_mm'][0]:.2f}–{q['machining_source_span_mm'][1]:.2f}",'38.10 overlap / clear','2.00 (ideal)']
        for x,t in zip(cols,vals):txt(x,y,t,'tiny')
    txt(45,1040,'HOLD PROMOTION — physical fit, tool access, residual section and connection/load-path evidence remain unresolved.','sub')
    s.append('</svg>');(HERE/'representative-node.svg').write_text('\n'.join(s),encoding='utf-8')

def export_sample(report):
    r=next(r for r in report['nodes'] if r['backing_member_id']=='WALL_STUD_NORTH_1')
    cx=1180.;b=r['brace_box_unchanged'];cz=b['center'][2]+(cx-b['center'][0])*b['axes'][0][2]/b['axes'][0][0]
    crop=[[cx-150,cz-160],[cx+150,cz-160],[cx+150,cz+160],[cx-150,cz+160]]
    def crop_prism(p):return prism(intersect(p['polygon_xz_mm'],crop),p['y_interval_mm'])
    for label,back in [('before',[box_prism(r['before_box'])]),('candidate',r['after_retained_convex_prisms'])]:
        shapes=[('BRACE_NORTH_111576_001_P01',crop_prism(box_prism(b)))]+[(f'WALL_STUD_NORTH_1_111576_041_P02_component_{i+1}',crop_prism(p)) for i,p in enumerate(back)]
        lines=['# DIGITAL NODE CROP ONLY; not shop cutting instructions. Units mm, world XYZ.','# Convex components share internal faces; union represents the retained timber.'];base=1
        for name,p in shapes:
            if area(p['polygon_xz_mm'])<EPS:continue
            vv=prism_vertices(p);n=len(vv)//2;lines.append('o '+name)
            lines += ['v '+' '.join(f'{x:.8f}' for x in v) for v in vv]
            # XZ CCW has normal -Y. Bottom cap faces outward at -Y; top at +Y.
            lines.append('f '+' '.join(str(base+i) for i in range(n)))
            lines.append('f '+' '.join(str(base+n+i) for i in reversed(range(n))))
            for i in range(n):j=(i+1)%n;lines.append(f'f {base+i} {base+n+i} {base+n+j} {base+j}')
            base+=len(vv)
        (HERE/f'representative-{label}.obj').write_text('\n'.join(lines)+'\n',encoding='utf-8')

if __name__=='__main__':main()
